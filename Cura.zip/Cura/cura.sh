#bash

python -m Cura.cura %*

